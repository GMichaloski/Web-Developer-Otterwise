function double(number){
    return number * 2;
}
console.log(double(double(2)));