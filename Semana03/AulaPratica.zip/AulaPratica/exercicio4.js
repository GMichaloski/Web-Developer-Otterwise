let arrayGenerico = ['Angela', 'Rosa', 'Ticiana', 'Carla', 'Renata'];
function imprimirNomes(array){
    for (let i = 0; i < array.length; i++){
        console.log(array[i]);
    }
}
imprimirNomes(arrayGenerico);