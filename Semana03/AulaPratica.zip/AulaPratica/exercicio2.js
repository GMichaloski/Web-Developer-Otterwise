let valor1 = 3, valor2 = 13, temp;
console.log(`Valor 1: ${valor1}`);
console.log(`Valor 2: ${valor2}`);

function inverterValores(num1, num2){
    valor1 = num2;
    valor2 = num1; 
}
inverterValores(valor1, valor2);
console.log(`Valor 1: ${valor1}`);
console.log(`Valor 2: ${valor2}`);
